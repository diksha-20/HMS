package com.cg.hms.bean;

public class Hotels {
	
	private int hotelId;
	private String city;
	private String hotelAddress;
	private String hotelDescription;
	private String hotelEmail;
	private String hotelName;
	private String hotelRating;
	private String phoneNo;
	private double averageRate;
	
	
	public Hotels() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getHotelId() {
		return hotelId;
	}


	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getHotelAddress() {
		return hotelAddress;
	}


	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}


	public String getHotelDescription() {
		return hotelDescription;
	}


	public void setHotelDescription(String hotelDescription) {
		this.hotelDescription = hotelDescription;
	}


	public String getHotelEmail() {
		return hotelEmail;
	}


	public void setHotelEmail(String hotelEmail) {
		this.hotelEmail = hotelEmail;
	}


	public String getHotelName() {
		return hotelName;
	}


	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}


	public String getHotelRating() {
		return hotelRating;
	}


	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	public double getAverageRate() {
		return averageRate;
	}


	public void setAverageRate(double averageRate) {
		this.averageRate = averageRate;
	}


	public Hotels(int hotelId, String city, String hotelAddress,
			String hotelDescription, String hotelEmail, String hotelName,
			String hotelRating, String phoneNo, double averageRate) {
		super();
		this.hotelId = hotelId;
		this.city = city;
		this.hotelAddress = hotelAddress;
		this.hotelDescription = hotelDescription;
		this.hotelEmail = hotelEmail;
		this.hotelName = hotelName;
		this.hotelRating = hotelRating;
		this.phoneNo = phoneNo;
		this.averageRate = averageRate;
	}
	
	
	
	

}
