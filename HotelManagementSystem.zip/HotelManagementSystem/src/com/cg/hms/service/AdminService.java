package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Hotels;
import com.cg.hms.exception.HotelException;

public interface AdminService {
	public abstract int addHotel(Hotels h) throws HotelException;
	public abstract void updateHotel(Hotels h) throws HotelException;
	public abstract List<Hotels> viewAllHotels() throws HotelException;
	public abstract void deleteHotel(int hotelId) throws HotelException;

}
