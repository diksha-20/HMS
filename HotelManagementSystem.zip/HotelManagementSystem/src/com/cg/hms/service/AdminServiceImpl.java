package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Hotels;
import com.cg.hms.dao.AdminDao;
import com.cg.hms.dao.AdminDaoImpl;
import com.cg.hms.exception.HotelException;

public class AdminServiceImpl implements AdminService {
	
	AdminDao dao=new AdminDaoImpl();

	@Override
	public int addHotel(Hotels h) throws HotelException {
		// TODO Auto-generated method stub
		return dao.addHotel(h);
	}

	@Override
	public void updateHotel(Hotels h) throws HotelException {
		
		dao.updateHotel(h);
		
	}

	@Override
	public List<Hotels> viewAllHotels() throws HotelException {
		return dao.viewAllHotels();
	}

	@Override
	public void deleteHotel(int hotelId) throws HotelException {
		
		dao.deleteHotel(hotelId);
		
	}

}
