package com.cg.hms.service;

import com.cg.hms.bean.User;
import com.cg.hms.dao.UserDao;
import com.cg.hms.dao.UserDaoImpl;
import com.cg.hms.exception.HotelException;

public class UserServiceImpl implements UserService {
	
	UserDao dao=new UserDaoImpl();

	@Override
	public User checkUser(String userName, String password)
			throws HotelException {
		// TODO Auto-generated method stub
		return dao.checkUser(userName, password);
	}

}
