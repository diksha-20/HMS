package com.cg.hms.util;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;



public class DBConnection {
	
	public static Connection getConnection() throws Exception{
		
		Connection con=null;
		Properties p=new Properties();
		FileReader f=new FileReader("resources/jdbc.properties");
		p.load(f);
		String driver=p.getProperty("driver");
		String url=p.getProperty("dburl");
		String user=p.getProperty("dbuser");
		String pass=p.getProperty("dbpass");
		Class.forName(driver);
		con=DriverManager.getConnection(url, user, pass);
		System.out.println("Driver loaded succesfully");
		
		
		return con;
		

	}

}
