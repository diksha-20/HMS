package com.cg.hms.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.hms.bean.Hotels;
import com.cg.hms.exception.HotelException;
import com.cg.hms.service.AdminService;
import com.cg.hms.service.AdminServiceImpl;

public class AdminConsole {
	
	private String currentUser;
	private AdminService serviceAdmin;
	private Scanner scan;
	public AdminConsole(String currentUser) {
		super();
		this.currentUser = currentUser;
	}
	
  public void start()
  {
	  scan=new Scanner(System.in);
	  serviceAdmin=new AdminServiceImpl();
	  System.out.println("Welcome "+currentUser);
	  
	  while(true)
	  {
		  System.out.println("****Enter your choice*********");
		  System.out.println("1.Add Hotel");
		  System.out.println("2.Update Hotel");
		  System.out.println("3.View Hotels");
		  System.out.println("4.Delete Hotel");
		  System.out.println("5.Log out");
		  int choice=scan.nextInt();scan.nextLine(); 
		  switch(choice)
		  {
		  case 1	:	addHotel();
		  				break;
		  				
		  case 2	:	updateHotel();
		  				break;
		  				
		  case 3	:	viewHotel();
		  				break;
		  				
		  case 4	:	deleteHotel();
		  				break;
		  				
		  case 5	:	System.out.println("Thank you!!");
		  				System.exit(0);
		  
		  
		  }
		  
	  }
  }
	  
	 public void addHotel()
	 {
		 Hotels h=new Hotels();
		System.out.println("Enter the Hotel name"); 
		String hotelName=scan.nextLine();
		System.out.println("Enter Hotel Address");
		String hotelAddress=scan.nextLine();
		System.out.println("Enter City");
		String city=scan.nextLine();
		System.out.println("Enter Description");
		String description=scan.nextLine();
		System.out.println("Enter email");
		String email=scan.nextLine();
		System.out.println("Enter Hotel Rating");
		String rating=scan.nextLine();
		System.out.println("Enter phone no");
		String phone=scan.nextLine();
		System.out.println("Enter Average rate per night");
		double avgRate=scan.nextDouble();
		h.setHotelName(hotelName);
		h.setCity(city);
		h.setHotelAddress(hotelAddress);
		h.setHotelDescription(description);
		h.setHotelEmail(email);
		h.setHotelRating(rating);
		h.setPhoneNo(phone);
		h.setAverageRate(avgRate);
		
		try {
			int count=serviceAdmin.addHotel(h);
			if(count>0)
			{
				System.out.println("Hotel Added Successfully");
			}
			else
			{
				System.out.println("Failed to add Hotel");
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
		
	 }
	 
	 
	 
	 public void updateHotel()
	 {
		 Hotels h=new Hotels();
		 System.out.println("Enter the Id of the Hotel to update");
		 int id=scan.nextInt();scan.nextLine();
		 System.out.println("***Details to Update***");
		 System.out.println("Enter the Hotel name"); 
			String hotelName=scan.nextLine();
			System.out.println("Enter Hotel Address");
			String hotelAddress=scan.nextLine();
			System.out.println("Enter City");
			String city=scan.nextLine();
			System.out.println("Enter Description");
			String description=scan.nextLine();
			System.out.println("Enter email");
			String email=scan.nextLine();
			System.out.println("Enter Hotel Rating");
			String rating=scan.nextLine();
			System.out.println("Enter phone no");
			String phone=scan.nextLine();
			System.out.println("Enter Average rate per night");
			double avgRate=scan.nextDouble();
			h.setHotelId(id);
			h.setHotelName(hotelName);
			h.setCity(city);
			h.setHotelAddress(hotelAddress);
			h.setHotelDescription(description);
			h.setHotelEmail(email);
			h.setHotelRating(rating);
			h.setPhoneNo(phone);
			h.setAverageRate(avgRate);
			
			
			try {
				serviceAdmin.updateHotel(h);
			} catch (HotelException e) {
			System.out.println(e.getMessage());
			}
			
	 }
	 
	 
	 public void viewHotel()
	 {
		 System.out.println("**********************************************************************************************************************************************************************************************");
		 System.out.println("Hotel Id          Hotel Name           Hotel Address          Hotel City           Hotel Description           Hotel Email            Hotel Rating           Hotel phone         Hotel Rate   ");
		 System.out.println("**********************************************************************************************************************************************************************************************");
		 
		 try {
			List<Hotels> list=serviceAdmin.viewAllHotels();
			 
			 for (Hotels hotels : list) {
				 
			 System.out.println(hotels.getHotelId()+"                 "+hotels.getHotelName()+"               "+hotels.getHotelAddress()+"               "+hotels.getCity()+"               "+hotels.getHotelDescription()+"               "+hotels.getHotelEmail()+"               "+hotels.getHotelRating()+"               "+hotels.getPhoneNo()+"               "+hotels.getAverageRate());
				
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	 }
	 
	 
	 
	 public void deleteHotel()
	 {
		 System.out.println("Enter the Hotel Id");
		 int id=scan.nextInt();
		 try {
			serviceAdmin.deleteHotel(id);
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
		 
		 
		 
		 
	 }
	  
  }


