package com.cg.hms.pl;

import java.util.Scanner;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;
import com.cg.hms.service.UserService;
import com.cg.hms.service.UserServiceImpl;

public class MainUI {
	
	public static void main(String[] args) {
		 UserService service=new UserServiceImpl();
		 Scanner s=new Scanner(System.in);
		 
		 
		 
		 System.out.println("Enter user name");
		  String user=s.nextLine();
		  System.out.println("Enter password");
		  String pass=s.nextLine();
		  
		  try {
			User u=service.checkUser(user, pass);
			String role=u.getRole();
			String username=u.getUserName();
			
			if(role.equalsIgnoreCase("admin"))
					{
				AdminConsole a=new AdminConsole(username);
				a.start();
				
					}
				
		
			
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		  
		s.close();
		
	}

}
