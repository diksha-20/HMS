package com.cg.hms.dao;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;

public interface UserDao {
	
	public User checkUser(String userName, String password) throws HotelException;

}
