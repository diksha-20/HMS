package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HotelException;
import com.cg.hms.util.DBConnection;

public class UserDaoImpl implements UserDao {

	@Override
	public User checkUser(String userName, String password)
			throws HotelException {
		Connection con=null;
		User user=null;
		try {
			con=DBConnection.getConnection();
			
				PreparedStatement pstmt=con.prepareStatement(QueryMapper.validateUser);
				pstmt.setString(1, userName);
				pstmt.setString(2, password);
				
				ResultSet r=pstmt.executeQuery();
				
				if(r.next())
				{
					String name=r.getString("username");
					String pass=r.getString("password");
					String role=r.getString("role");
					user=new User();
					user.setUserName(name);
					user.setPassword(pass);
					user.setRole(role);
				}
				
				
				
				
				
		} catch (SQLException e) {
		throw new HotelException("Database error 1 "+e.getMessage());
		} catch (Exception e) {
			//throw new HotelException("Database error 2 "+e.getMessage());
			e.printStackTrace();
		}
		
		
				
		return user;
	}

}
