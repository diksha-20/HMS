package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hms.bean.Hotels;
import com.cg.hms.exception.HotelException;
import com.cg.hms.util.DBConnection;

public class AdminDaoImpl implements AdminDao{

	@Override
	public int addHotel(Hotels h) throws HotelException {
		int count=0;
		Connection con=null;
		try {
			con=DBConnection.getConnection();
			
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.addHotel);
			pstmt.setString(1, h.getHotelName());
			pstmt.setString(2, h.getHotelAddress());
			pstmt.setString(3, h.getHotelDescription());
			pstmt.setDouble(4, h.getAverageRate());
			pstmt.setString(5, h.getPhoneNo());
			pstmt.setString(6, h.getHotelRating());
			pstmt.setString(7, h.getHotelEmail());
			pstmt.setString(8, h.getCity());
			
			count=pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new HotelException("Failed to Add Hotel "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to Add Hotel "+e.getMessage());
		}
		
		return count;
	}

	@Override
	public void updateHotel(Hotels h) throws HotelException {
			Connection con=null;
			int count=0;
			try {
				con=DBConnection.getConnection();
				PreparedStatement pstmt=con.prepareStatement(QueryMapper.updateHotel);
				pstmt.setString(1, h.getHotelName());
				pstmt.setString(2, h.getHotelAddress());
				pstmt.setString(3, h.getHotelDescription());
				pstmt.setDouble(4, h.getAverageRate());
				pstmt.setString(5, h.getPhoneNo());
				pstmt.setString(6, h.getHotelRating());
				pstmt.setString(7, h.getHotelEmail());
				pstmt.setString(8, h.getCity());
				pstmt.setInt(9, h.getHotelId());
				
				count=pstmt.executeUpdate();
				
				if(count>0)
				{
					System.out.println("Hotel Updated Successfully!!");
				}
			} catch (SQLException e) {
				System.out.println("Failed to Update Hotel "+e.getMessage());
			} catch (Exception e) {
				System.out.println("Failed to Update Hotel "+e.getMessage());
				
			}

		
	}

	@Override
	public List<Hotels> viewAllHotels() throws HotelException {
		Connection con=null;
		List<Hotels> list=new ArrayList<Hotels>();
		
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.listHotels);
			ResultSet r=pstmt.executeQuery();
			while(r.next())
			{
				Hotels h=new Hotels();
				h.setHotelId(r.getInt("HOTELID"));
				h.setHotelName(r.getString("HOTELNAME"));
				h.setHotelAddress(r.getString("HOTELADDRESS"));
				h.setHotelDescription(r.getString("HOTELDESCRIPTION"));
				h.setHotelEmail(r.getString("HOTELEMAIL"));
				h.setHotelRating(r.getString("HOTELRATING"));
				h.setPhoneNo(r.getString("PHONENO"));
				h.setAverageRate(r.getDouble("AVGRATEPERNIGHT"));
				h.setCity(r.getString("CITY"));
				
				list.add(h);
				
			}
			
					
		} catch (SQLException e) {
			throw new HotelException("Failed to Show "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to Show "+e.getMessage());
		}
		return list;
	}

	@Override
	public void deleteHotel(int hotelId) throws HotelException {
		
		Connection con=null;
		int count=0;
		try {
			con=DBConnection.getConnection();
			PreparedStatement pstmt=con.prepareStatement(QueryMapper.deleteHotel);
			pstmt.setInt(1, hotelId);
			count=pstmt.executeUpdate();
			if(count>0)
			{
				System.out.println("Hotel deleted Successfully!!!");
			}
		} catch (SQLException e) {
			throw new HotelException("Failed to delete Hotel "+e.getMessage());
		} catch (Exception e) {
			throw new HotelException("Failed to delete Hotel "+e.getMessage());
		}
		
		
		
	}

}
