package com.cg.hms.dao;

public interface QueryMapper {
	
	public static final String validateUser="select username,password,role from users where username=? and password=?";
	public static final String addHotel="insert into hotels(HOTELID,HOTELNAME,HOTELADDRESS, HOTELDESCRIPTION,AVGRATEPERNIGHT,PHONENO,HOTELRATING,HOTELEMAIL,CITY)values(hId.nextval,?,?,?,?,?,?,?,?)";
	public static final String updateHotel="update hotels set  HOTELNAME=?,HOTELADDRESS=?, HOTELDESCRIPTION=?, AVGRATEPERNIGHT=?, PHONENO=?, HOTELRATING=?, HOTELEMAIL=?, CITY=? where HOTELID=?";
	public static final String listHotels="select HOTELID,HOTELNAME,HOTELADDRESS, HOTELDESCRIPTION,AVGRATEPERNIGHT,PHONENO,HOTELRATING,HOTELEMAIL,CITY from hotels ";
	public static final String deleteHotel="delete from hotels where HOTELID=?";
}
