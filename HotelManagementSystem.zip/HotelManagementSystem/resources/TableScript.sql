CREATE TABLE hotels (
hotelId number(4) PRIMARY KEY,
city varchar2(30),
hotelName varchar2(30),
hotelAddress varchar2(30),
hotelDescription varchar2(100),
avgRatePerNight  number(20,10),
phoneNo number(10),
hotelRating varchar2(10),
hotelEmail varchar2(40)
);





create table Room_Details(
  2  room_id number(4) primary key,
  3  room_no varchar2(3),
  4  room_type varchar2(20),
  5  per_night_rate number(20,10),
  6  availability varchar2(5),
  7  hotel_id number references hotels(hotelId)
  8  on delete cascade
  9  );